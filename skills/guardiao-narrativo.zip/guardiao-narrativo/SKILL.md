---
name: guardiao-narrativo
description: Revisa e reescreve textos institucionais (propostas, relatórios, comunicações) para garantir que a voz, o tom e o vocabulário estejam alinhados ao posicionamento real da organização — e para remover "cheiro de texto gerado por IA". Use sempre que o usuário pedir para "revisar o texto", "deixar isso com a nossa cara", "tirar o tom de robô", ou depois que outra skill (como arquiteto-de-projetos) gerar um rascunho que precisa passar por revisão de voz antes de ir para um financiador ou público externo.
---

# Guardião Narrativo

Esta skill protege a voz institucional da organização — garante que nenhum texto saia soando genérico, assistencialista ou "com cheiro de IA", mesmo quando foi produzido com ajuda de outras skills.

## Quando usar

- Depois que a skill arquiteto-de-projetos (ou qualquer outra) gerar um rascunho de texto institucional
- O usuário pede explicitamente para revisar tom, voz ou "deixar com a nossa cara"
- Antes de qualquer texto sair para um financiador, parceiro ou público externo

## A voz institucional (exemplo: Instituto Raízes do Pirambu)

Cada organização tem seu próprio guia de voz — o exemplo abaixo é do caso institucional usado no workshop, e deve ser adaptado para a voz real de cada organização usando esta skill.

**Não fala assim** → **Fala assim**
- "populações vulneráveis" → "comunidades com poder"
- "beneficiários passivos de assistência" → "protagonistas do próprio território"
- "oferecemos assistência" → "oferecemos estrutura para que o território cuide de si mesmo"
- Tom de gratidão/caridade → Tom de resultado e coautoria

Regra geral: se o texto soa como pedido de esmola ou descreve a comunidade como incapaz, está errado — reescrever.

## Checklist anti-"cheiro de IA"

Aplicar sempre, independentemente da organização:

- **Nada de travessão (—) para conectar ideias.** Preferir frases mais curtas ou pontuação simples.
- **Banir clichês de texto gerado por IA**: "aprofundar" (delve), "alavancar", "impecável", "sem costura" (seamless), "fundamental" (pivotal) em excesso, "tapeçaria" (tapestry), e construções do tipo "não é só X, é Y".
- **Forçar variação no tamanho das frases**: alternar frases bem curtas (menos de 6 palavras) com frases mais longas (acima de 25 palavras). Texto todo em frases médias e uniformes é o maior sinal de "cheiro de IA".
- **Adicionar marcadores humanos quando fizer sentido**: números específicos e reais em vez de arredondados, referências concretas de tempo e lugar, um leve tom de informalidade onde o gênero do texto permitir.
- **Zero-shot em exemplos genéricos**: nunca abrir um parágrafo com "Imagine um mundo onde..." ou equivalentes.

## Processo

1. Ler o texto recebido e identificar qualquer trecho que viole a voz institucional (ver acima) ou o checklist anti-IA.
2. Reescrever apenas os trechos problemáticos — não reescrever o texto inteiro se só uma parte precisa de ajuste.
3. Explicar, em uma lista curta ao final, o que foi mudado e por quê (para o usuário aprender a reconhecer os próprios desvios ao longo do tempo, não só receber o texto corrigido).

## Regras importantes

- Nunca suavizar dados reais para soar mais "positivo" — a voz institucional é sobre dignidade, não sobre maquiar números.
- Se o texto original já estiver alinhado, dizer isso claramente em vez de reescrever por reescrever.
- Esta skill não inventa fatos novos — só ajusta forma, tom e vocabulário do que já foi escrito.

## Formato de saída

Texto revisado, seguido de:

```
## O que foi ajustado
- [trecho] → [motivo da mudança]
```
