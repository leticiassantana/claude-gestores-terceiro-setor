---
name: analista-de-editais
description: Analisa editais, chamadas de financiamento e oportunidades de captação de recursos, avaliando o fit estratégico com a missão, teoria de mudança e capacidade operacional da organização. Use sempre que o usuário colar o texto de um edital, pedir para "analisar" ou "ver se vale a pena" um financiamento, perguntar sobre elegibilidade, ou pedir um resumo de requisitos de uma chamada de projetos. Também use quando o usuário pedir para comparar dois ou mais editais entre si.
---

# Analista de Editais

Esta skill avalia oportunidades de financiamento (editais, chamadas públicas ou privadas) contra o perfil real da organização — não apenas resume o edital, mas emite um parecer de fit estratégico.

## Quando usar

- O usuário cola o texto (ou um link/resumo) de um edital e pede análise
- O usuário pergunta se a organização é elegível para um financiamento específico
- O usuário quer comparar dois ou mais editais para decidir onde investir tempo de captação
- O usuário pede para identificar riscos ou pontos de atenção antes de decidir concorrer

## O que a skill precisa saber sobre a organização

Antes de analisar qualquer edital, use o que estiver disponível no Project (Knowledge) sobre:
- Missão, teoria de mudança e território de atuação
- Público atendido e faixa etária
- Capacidade operacional atual (equipe, orçamento, parcerias)
- Histórico de projetos aprovados e executados

Se essas informações não estiverem disponíveis no Project, pergunte objetivamente antes de prosseguir — um parecer de fit sem esse contexto é só um resumo do edital, não uma análise.

## Processo de análise

1. **Extrair os requisitos objetivos do edital**: valor disponível, prazo de execução, território elegível, público-alvo exigido, contrapartidas, documentação de habilitação, prazo de submissão.
2. **Cruzar com o perfil da organização**: para cada requisito objetivo, marcar como Atende / Não atende / Atende parcialmente (e explicar o que falta).
3. **Avaliar fit com a missão**: o edital financia o que a organização já faz bem, ou pediria adaptar a atuação para caber no edital? Adaptar demais para caber num edital é um risco — nomeie isso quando acontecer.
4. **Avaliar fit com a capacidade operacional**: a equipe atual consegue executar isso além do que já faz? Marque se o edital exigiria contratação, parceria ou expansão de escopo.
5. **Emitir o parecer final**, sempre em 3 partes:
   - **Nível de fit**: Alto / Médio / Baixo, com justificativa em 1-2 frases
   - **Principais riscos ou pontos de atenção**: lista objetiva, sem suavizar
   - **Recomendação**: concorrer, concorrer com ressalvas, ou não concorrer — e por quê

## Regras importantes

- Nunca infle o fit para "vender" a ideia de concorrer. O papel desta skill é dar clareza, não entusiasmo.
- Se o edital tiver prazo de submissão apertado dado o tempo de preparo típico da organização, isso é um risco a ser nomeado explicitamente, não uma nota de rodapé.
- Se faltar informação no próprio edital (ex: valor não divulgado, critérios vagos), diga isso claramente em vez de assumir.
- Não invente números de outros projetos da organização — use apenas o que está no Project ou o que o usuário fornecer.

## Formato de saída

Sempre estruture a resposta como:

```
## Requisitos objetivos
[tabela ou lista: requisito → status → observação]

## Fit com a missão
[parágrafo curto]

## Fit com a capacidade operacional
[parágrafo curto]

## Parecer
Nível de fit: [Alto/Médio/Baixo]
Riscos: [lista]
Recomendação: [concorrer / concorrer com ressalvas / não concorrer]
```
