---
name: arquiteto-de-projetos
description: Estrutura e redige propostas de projeto para editais e chamadas de financiamento, a partir dos requisitos do edital e do contexto institucional da organização. Use sempre que o usuário pedir para "escrever uma proposta", "montar um projeto para o edital X", gerar objetivos/metas/indicadores para uma submissão, ou transformar uma ideia solta em um projeto estruturado pronto para submissão. Normalmente usada depois da análise de um edital (ver skill analista-de-editais).
---

# Arquiteto de Projetos

Esta skill transforma um edital analisado + o contexto institucional da organização em uma proposta de projeto estruturada, pronta para revisão humana antes da submissão.

## Quando usar

- Depois que um edital já foi analisado (idealmente com a skill analista-de-editais) e a decisão foi concorrer
- O usuário pede para "montar a proposta" ou "escrever o projeto" para uma chamada específica
- O usuário quer transformar uma ideia de intervenção em objetivos, metas e indicadores formais

## O que a skill precisa ter em mãos

- O texto do edital (requisitos, formato exigido, seções obrigatórias)
- O contexto institucional do Project: missão, teoria de mudança, metodologia, histórico de projetos anteriores aprovados
- Se disponível, um projeto anterior aprovado da própria organização — usar como referência de nível de detalhe e tom esperado pelo financiador, não como texto para copiar

## Processo

1. **Mapear a estrutura exigida pelo edital.** Cada edital tem seu próprio formato de seções — não impor um modelo genérico. Se o edital não especificar formato, usar como padrão: Resumo → Justificativa/Problema → Objetivos e Metas → Metodologia/Atividades → Cronograma → Orçamento (alto nível) → Indicadores de Monitoramento → Sustentabilidade/Continuidade.
2. **Ancorar a justificativa na teoria de mudança real da organização** — não reescrever a missão do zero a cada proposta, adaptar a teoria de mudança existente ao recorte específico do edital.
3. **Gerar objetivos e metas em formato SMART**, coerentes com a capacidade operacional real (não prometer o que a organização não tem estrutura para entregar).
4. **Redigir indicadores mensuráveis**, preferencialmente reaproveitando os indicadores que a organização já usa (ver Knowledge/indicadores), para não criar um sistema de medição paralelo que ninguém vai manter depois.
5. **Sinalizar lacunas** explicitamente no rascunho: onde falta um número, uma decisão de escopo ou uma confirmação de parceria, marcar com `[PENDENTE: ...]` em vez de inventar.

## Regras importantes

- Esta skill produz um **rascunho para revisão humana**, nunca um texto final pronto para envio sem revisão.
- Não inventar números de impacto, parcerias ou resultados que não estejam no Project ou não tenham sido fornecidos pelo usuário.
- Preservar a voz institucional da organização (ver skill guardiao-narrativo) — não deixar o texto soar genérico ou "assistencialista" se isso contradiz o posicionamento real da organização.
- Se o edital pedir algo que a organização não faz e não tem como adaptar de forma honesta, dizer isso claramente em vez de forçar um encaixe.

## Formato de saída

Proposta estruturada em seções claras (conforme exigido pelo edital ou o padrão acima), com `[PENDENTE: ...]` marcado em qualquer lacuna, seguida de uma lista curta ao final: "Pontos que precisam de revisão humana antes de submeter."
